# Studii — Google Sites starter

This is a self-contained Studii prototype.

Important:
- Google Sites does not directly run raw HTML/CSS/JS code.
- Host `index.html` somewhere that provides a public HTTPS URL, then embed that URL in Google Sites.
- This starter stores data locally in the browser with localStorage. It is NOT a secure multi-user backend yet.
- The AI Study Helper shown here is a UI placeholder. A real AI API should be called from a secure backend so the API key is never exposed to students.
- Real student accounts, teacher permissions, shared classroom chats, and shared database data require a backend/authentication system.

Easy hosting options:
1. GitHub Pages: upload index.html to a repository and enable Pages.
2. Netlify/Vercel: deploy the folder and use the generated HTTPS URL.
3. Google Apps Script: use HtmlService to serve the page if you want to keep the project inside Google.

Then in Google Sites:
Insert -> Embed -> By URL -> paste the hosted HTTPS URL.

The design is pastel yellow + pastel blue and intended for Chromebooks/school laptops.
